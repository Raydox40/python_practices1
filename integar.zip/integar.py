firstvalue = 34
secondvalue = 45

print(firstvalue + secondvalue)